package debuggerexample;

import java.util.Scanner;
/**
 *
 * @author Sandeep Nadendla
 */
public class MainDriver {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Enter size of the array: ");
        int size = keyboard.nextInt();
        int[] arrayInt = new int[size];

        fillArray(arrayInt);

        int results = searchValue(arrayInt, 2);

        System.out.println("The index of searched element in the array is: " + results);
    }

    public static void fillArray(int[] arrayInt) {
        Scanner keyboard = new Scanner(System.in);
        for (int i = 0; i < arrayInt.length; i++) {
            System.out.print("Enter the " + (i + 1) + " value in array: ");
            arrayInt[i] = keyboard.nextInt();
            i = i + 2;
        }

    }

    public static int searchValue(int[] arrayInt, int valInt) {
        int result = -1;
        for (int i = 0; i < arrayInt.length; i++) {
            System.out.println("Enter into while loop in search method");
            if (i < arrayInt.length && arrayInt[i] == valInt) {
                result += i;//manideep
            }
            //result = i * (result)/i;
        }
        return result;
    }

}

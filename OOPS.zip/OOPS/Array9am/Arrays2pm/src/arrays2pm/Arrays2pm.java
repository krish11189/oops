package arrays2pm;

import java.util.Scanner;

public class Arrays2pm {
    public static void main(String[] args) {
        //Arrays -> same data type and fixed length
        final int SIZE = 5;
        int[] grades = new int[SIZE];
        grades[0] = 98;grades[1] = 76;
        //int[] grades = {45,56,98};
        Scanner keyboard = new Scanner(System.in);
        for(int i=2;i<grades.length;i++){
            System.out.println("Enter the next grade: ");
            grades[i] = keyboard.nextInt();
        }
        //grades.length = 25; - length cannot be changed in runtime
        for(int i=0;i<SIZE;i++){
            System.out.println("The grade of student "+(i)+" is:"+grades[i]);
        }
        System.out.println("The address (ref var) : "+grades);
        //copy arrays 
        String[] names = {"Dheemanth","Teja","Navya"};
        String[] copyNames = new String[3];
        copyNames = names; //copied reference
        System.out.println("The copy name "+copyNames[0]);
        System.out.println("The name "+names[0]);
        
    }
    
}

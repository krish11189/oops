package array9am;

import java.util.Scanner;

public class Array9am {

    public static void main(String[] args) {
       // Arrays - same datatype and fixed length
       /*
       final int SIZE = 7;
       int[] grade = new int[SIZE];
       grade[0] = 80; grade[1] = 87;
       Scanner keyboard = new Scanner(System.in);
       for(int i=2;i<grade.length;i++)
       {
           System.out.println("Enter the next grade: ");
           grade[i] = keyboard.nextInt();
       }
      // grade.length = 25; - cannot change the size during runtime
        System.out.println("The address (ref var) : "+grade);
        for(int i=0;i<grade.length;i++){
            System.out.println("The grade of student "+i+" is :"+grade[i]);
        }
        */
       //String[] names = {"naveen","narendra","sandeep","bikash","harsha"};
        //System.out.println(names[2]);
        //copy arrays 
        int[] grades = {56,78,90,73};
        int[] copyGrades = new int[4];
        
        //copyGrades = grades;
      // System.out.println("the array element: "+grades[0]);
       //System.out.println("the copied array element: "+copyGrades[0]);
       for(int i=0;i<grades.length;i++){
           copyGrades[i] = grades[i];
       }
       for(int i=0;i<grades.length;i++){
           System.out.println(copyGrades[i]);
       }
    }
    
}

package arrays;

import java.util.Scanner;

public class Arrays {

    public static void main(String[] args) {
        final int SIZE = 6;
        int[] grade = new int[SIZE];
        String[] names = {"Sandeep", "Narendra", "Puspha", "Mogulayya"};
        /*  grade[0] = 10;
        grade[1] = 8;
        Scanner keyboard = new Scanner(System.in);
        for (int i = 2; i < grade.length; i++) {
            System.out.println("Enter the next Grade: ");
            grade[i] = keyboard.nextInt();
        }
        // grade.length=10;  size of the array cannot change
        System.out.println(grade);
        System.out.println("Grades are");
        for (int i = 0; i < grade.length; i++) {
            System.out.print(grade[i]+" ");
        }
        System.out.println("");
         */
        // Enhanced for loop
        System.out.println("__________Enhanced For Loop___________");
        for (String anElement : names) {
            System.out.println(anElement);
        }
        System.out.println("__________For Loop___________");
        for (int index = 0; index < names.length; index++) {
            System.out.println(names[index]);
        }
    }

}

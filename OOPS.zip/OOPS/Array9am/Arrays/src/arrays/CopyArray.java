package arrays;

public class CopyArray {

    public static void main(String[] args) {
        int[] grade = {6, 15, 13, 21, 25, 21};
        int[] copyGrade = new int[6];
        /* copyGrade=grade;
        System.out.println(grade[0]);
        System.out.println(copyGrade[0]);*/

        for (int i = 0; i < grade.length; i++) {
            copyGrade[i] = grade[i];
        }

        for (int i = 0; i < copyGrade.length; i++) {
            System.out.println(copyGrade[i]);
        }
        System.out.println("Address of grade: " + grade);
        System.out.println("Address of copygrade: " + copyGrade);
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;


/**
 *
 * @author Instructor
 */
public class SalesDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
        //1.Declare and initialize a Scanner object to read from the file "inputFile2.txt"
        //2.Declare and initialize a PrintWriter object to write output to the file "outputFileText2.txt"
        //3.create an ArrayList of Retailer objects with name "retailers"
        //4.Read Data
   
        
        //while(scanner.hasNext()){ //Read line
            //5.Read Retailer name and address
            //6.Declare and initialize an object for retailer using above read values
            
            //7.Read all beers available for the retailer. Loop starts here
            //do{ 
                // 8.Read all details of a beer
                // 9.Declare and initialize an object for Beer using above read values
                // 10.Add the declared beer object to retailer object created in the outer loop
                
            //}while(condition); //End the loop if reading all the Beer objects for a retailer is completed
            // 11.Add the retailer object created in this loop to variable retailers
        }

        /*!!!For bellow statements, use loops to retrive required Retailer object from arraylist "retailers"
             Do not hardcode indexes to retrive data from variable retailers*/

        // 12.Print "******Walmart Inventory for Beer's*****"
        // 13.Invoke toString() on retailer "Walmart" and print object

        // 14.Print "******Remove Wells IP from Walmart*****"
        // 15.Remove Beer with name "Wells IP" from retailer "Walmart" in retailers and print removed beer details.
        
        // 16.Print "****List of strong beer from Hy-Vee****"
        // 17.Print all strong beer available in Hy-Vee
        
        // 18.Print "****List of light beer from Sam's Club****"
        // 19.Print all light beer available in Sam's Club
        
        // 20.Print  "****Count of different beers available from each retailer****"
        // 21.Print count of different beers available from each retailer
        
        // 22.Print "****All different beers available from all retailers****"
        // 23.Print Names of all different beers from all retailers.
        
        // 24.Close PrintWriter object
    }
    
}

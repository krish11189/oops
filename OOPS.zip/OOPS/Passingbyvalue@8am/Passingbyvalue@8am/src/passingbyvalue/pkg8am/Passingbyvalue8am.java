package passingbyvalue.pkg8am;

public class Passingbyvalue8am {

    public static void main(String[] args) {
        int x = 10;
        int y = 20;
        int z = sum(x, y + 1);
        System.out.println("Sum is: " + z);
        System.out.println("in main x= " + x + " y= " + y);
    }

    public static int sum(int x, int y) {
        int sum = 0;
        sum = x + y;
        x = x + 1;
        y--;
        System.out.println("in method x= " + x + " y= " + y);
        return sum;
    }
}

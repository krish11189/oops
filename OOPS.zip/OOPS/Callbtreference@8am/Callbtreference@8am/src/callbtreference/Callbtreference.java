package callbtreference;

public class Callbtreference {

    public static void main(String[] args) {
        int[] nums = new int[5];
        for (int i = 0; i < nums.length; i++) {
            System.out.print(nums[i] + " ");
        }
        initNums(nums);
        System.out.println("\n In main after the call");
        for (int i = 0; i < nums.length; i++) {
            
            System.out.print(nums[i] + " ");
        }

    }

    public static void initNums(int[] arraynum) {
        for (int i = 0; i < arraynum.length; i++) {
            arraynum[i] = 10 * i;
        }
    }

}

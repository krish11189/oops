package callbtreference;

public class ByreferenceUsingStrings {

    public static void main(String[] args) {
        String name = "Sandeep";
        int size = showLength(name);
        System.out.println(size);
        System.out.println("In Main after call: " + name);

    }

    public static int showLength(String str) {
        System.out.println("In showLength: " + str);
        str = "Ravi";
        System.out.println("In showLength after change: " + str);
        return str.length();
    }

}

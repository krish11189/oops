/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package writefile2pm;

import java.io.*;
import java.util.Scanner;

public class ReadFile {

    public static void main(String[] args) throws FileNotFoundException {
       //read from the file - open the file
       File myFile = new File("inputFile.txt");
       if(!myFile.exists()){
           System.out.println("The inputFile.txt is not found");
           System.exit(0);
       }
       Scanner readFile = new Scanner(myFile);
       double sum=0;
       //iteration reading from the file - for or while
       while(readFile.hasNext()){
           sum = sum + readFile.nextDouble();
       }
        System.out.println("The sum of above number is: "+sum);
        readFile.close();
    }
    
}

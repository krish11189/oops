package writefile2pm;
import java.io.*; 
import java.util.Scanner;

public class WriteFile2pm {
    public static void main(String[] args) throws FileNotFoundException {
        //write the file - open the file
        PrintWriter outputFile = new PrintWriter("DataFile.txt");
        //read from the keyboard
        Scanner keyboard = new Scanner(System.in);
        for(int i=0;i<5;i++){
            System.out.println("Enter the name: ");
            String name = keyboard.nextLine();
            System.out.println("Enter the age: ");
            int age = keyboard.nextInt();
            //manipulate the file
            outputFile.println(name);
            outputFile.println(age);
            keyboard.nextLine();
        }
        //close the file
        outputFile.close();
    }
    
}

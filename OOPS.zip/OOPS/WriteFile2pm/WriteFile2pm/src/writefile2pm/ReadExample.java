/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package writefile2pm;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadExample {

    public static void main(String[] args) throws FileNotFoundException {
         File myFile = new File("inputFile.txt");
       if(!myFile.exists()){
           System.out.println("The inputFile.txt is not found");
           System.exit(0);
       }
       Scanner readFile = new Scanner(myFile);
       double sum=0,sqrt=0;
       //iteration reading from the file - for or while
       for(int i=0;i<5;i++){
           double num = readFile.nextDouble();
           sum = sum + num;
       }
        System.out.println("The sum of above number is: "+sum);
        readFile.close();
        readFile = new Scanner(myFile);
        for(int j=0;j<5;j++){
            double num = readFile.nextDouble();
            sqrt = sqrt + Math.sqrt(num);
        }
        System.out.println("The sum of sq rt of numbers are: "+sqrt);
        readFile.close();
    }
    
}
